
public class AssignVariable {

	public static void main(){
		byte b = 127;
		short s = 32767;
		int i = 2000000000;
		long l = 919827112351L;
		char c = 'c';
		boolean bool = false;
		float f = 0.5f;
		double d = 0.1234567891011;
		String str = "Palo Alto, CA";
	}
}
