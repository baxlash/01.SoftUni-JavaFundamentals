import java.util.Scanner;

public class SumNumbers1ToN {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int number = sc.nextInt();
		sc.close();
		
		int sum = 0;
		
		for (int i=1; i<=number; i++){
			sum += i;
		}
		
		System.out.println(sum);
	}
}
